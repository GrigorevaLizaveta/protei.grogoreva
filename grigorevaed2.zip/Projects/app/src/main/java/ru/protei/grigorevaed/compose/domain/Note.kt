package ru.protei.grigorevaed.compose.domain

class Note (
    var title: String,
    var text: String
)