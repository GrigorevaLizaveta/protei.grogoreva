package ru.protei.grigorevaed

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.protei.grigorevaed.domain.Note
import ru.protei.grigorevaed.ui.theme.GrigorevaedTheme


var listNote = mutableListOf<Note>()


fun addNote() {
    listNote.add(Note("Заметка 1", "Текст"))
    listNote.add(Note("Заметка 2", "Текст"))
    listNote.add(Note("Заметка 3", "Текст"))
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GrigorevaedTheme {
                addNote()
                Surface(modifier = Modifier.fillMaxHeight().padding(start = 32.dp, top = 32.dp) ,color = MaterialTheme.colorScheme.background)
                    {
                        ShowNote()
                    }
                }
            }
        }
    }

@Composable
fun ShowNote() {
    Column {
        for (note in listNote){
            Text(text = note.title, fontSize = 48.sp)
            Text(text = note.text + "\n", fontSize = 24.sp)
       }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun ShowNotePreview() {
    GrigorevaedTheme {
        ShowNote()
    }
}