package ru.protei.grigorevaed.domain

class Note (
    var title: String,
    var text: String
)